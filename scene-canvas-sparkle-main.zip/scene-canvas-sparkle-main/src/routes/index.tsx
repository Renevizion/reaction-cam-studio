import { createFileRoute } from "@tanstack/react-router";
import Compositor from "@/components/Compositor";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Parallax Studio — Screen + Webcam Compositor" },
      {
        name: "description",
        content:
          "Browser-based screen and webcam compositor with free-form layered parallax, drag/resize transforms, and one-click recording.",
      },
      { property: "og:title", content: "Parallax Studio" },
      {
        property: "og:description",
        content: "Client-side screen + webcam layered compositor with recording.",
      },
    ],
  }),
});

function Index() {
  return <Compositor />;
}
